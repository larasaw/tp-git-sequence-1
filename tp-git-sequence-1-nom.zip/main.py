for i in range(10):
    print('This is the value of i: ', i)